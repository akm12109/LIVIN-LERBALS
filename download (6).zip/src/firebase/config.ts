// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const firebaseConfig = {
  apiKey: "AIzaSyA8Yvk1nqfR8LtlIgE__LtFjA_tGURsRQc",
  authDomain: "app-11-d08d7.firebaseapp.com",
  projectId: "app-11-d08d7",
  storageBucket: "app-11-d08d7.appspot.com",
  messagingSenderId: "1060756860273",
  appId: "1:1060756860273:web:bc688b567e800408dbdad0",
  measurementId: "G-1WLMX2YX5Q"
};
